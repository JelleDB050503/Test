#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

BACKUP_DIR="manage-db/backups"
LOG_DIR="logs"
mkdir -p "$BACKUP_DIR" "$LOG_DIR"

# Create a new log file per start
START_TS=$(date +"%Y%m%d_%H%M%S")
BACKEND_LOG="$LOG_DIR/backend_$START_TS.log"
FRONTEND_LOG="$LOG_DIR/frontend_$START_TS.log"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log() { echo "[$(timestamp)] $*"; }

log "Stopping old backend/frontend..."
pkill -f "dotnet run" 2>/dev/null || true
pkill -f "npm run dev" 2>/dev/null || true
sleep 2

log "Backing up database (if exists)..."
if mariadb -u root -proot -e "USE petanque;" >/dev/null 2>&1; then
  /usr/bin/mariadb-dump -u root -proot petanque > "$BACKUP_DIR/backup_$START_TS.sql"
  log "Backup created successfully."
else
  log "Database 'petanque' not found — skipping backup."
fi

log "Starting backend..."
(
  cd Petanque/Petanque.Api
  export DOTNET_CLI_TELEMETRY_OPTOUT=1
  # redirect nohup output to /dev/null to hide the message
  nohup bash -c 'dotnet run 2>&1 | while IFS= read -r line; do echo "[$(date +"%Y-%m-%d %H:%M:%S")] $line"; done' >> "../../$BACKEND_LOG" 2>&1 </dev/null &
  disown
)
sleep 2

log "Starting frontend..."
(
  cd Petanque/PetanqueFrontend
  export VITE_API_URL="http://localhost:5251/api"
  nohup bash -c 'npm run dev 2>&1 | while IFS= read -r line; do echo "[$(date +"%Y-%m-%d %H:%M:%S")] $line"; done' >> "../../$FRONTEND_LOG" 2>&1 </dev/null &
  disown
)
sleep 2

log "Waiting for frontend (http://localhost:5173)..."
until curl -sSf http://localhost:5173/ >/dev/null 2>&1; do
  log "Still starting frontend..."
  sleep 1
done

log "Waiting for backend (http://localhost:5251/api/seizoenen)..."
until curl -sSf http://localhost:5251/api/seizoenen >/dev/null 2>&1; do
  log "Still starting backend..."
  sleep 1
done

log "Opening browser..."
xdg-open http://localhost:5173/ >/dev/null 2>&1 || true

log "✅ Petanque app running — logs: $BACKEND_LOG, $FRONTEND_LOG"
