using System;
using Microsoft.EntityFrameworkCore;
using Petanque.Storage;

namespace Petanque.Tests
{
    // Test-only DbContext that avoids configuring MySQL and provides a minimal model suitable for InMemory testing.
    public class TestPetanqueContext : Id312896PetanqueContext
    {
        public TestPetanqueContext(DbContextOptions<Id312896PetanqueContext> options)
            : base(options)
        {
        }

        // Do not call base.OnConfiguring to avoid registering MySQL provider from production code.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // intentionally left blank for tests
        }

        // Replace the production model with a minimal test-friendly model.
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Dagklassement
            modelBuilder.Entity<Dagklassement>(entity =>
            {
                entity.HasKey(e => e.DagklassementId);
                entity.Property(e => e.DagklassementId);
                entity.Property(e => e.SpeeldagId);
                entity.Property(e => e.SpelerId);
                entity.Property(e => e.Hoofdpunten).HasDefaultValue(0);
                entity.Property(e => e.PlusMinPunten).HasDefaultValue(0);
            });

            // Speler
            modelBuilder.Entity<Speler>(entity =>
            {
                entity.HasKey(e => e.SpelerId);
                entity.Property(e => e.SpelerId);
                entity.Property(e => e.Naam).IsRequired(false);
                entity.Property(e => e.Voornaam).IsRequired(false);
            });

            // Seizoen (production model uses DateOnly; provide a key so InMemory accepts the type)
            modelBuilder.Entity<Seizoen>(entity =>
            {
                entity.HasKey(e => e.SeizoensId);
                entity.Property(e => e.SeizoensId);
                entity.Property(e => e.Startdatum);
                entity.Property(e => e.Einddatum);
            });

            // Speeldag
            modelBuilder.Entity<Speeldag>(entity =>
            {
                entity.HasKey(e => e.SpeeldagId);
                entity.Property(e => e.SpeeldagId);
                entity.Property(e => e.Datum);
                entity.Property(e => e.SeizoensId).IsRequired(false);
            });

            // Seizoensklassement - provide a key so InMemory can track entries
            modelBuilder.Entity<Seizoensklassement>(entity =>
            {
                entity.HasKey(e => e.SpelerId);
                entity.Property(e => e.SpelerId);
                entity.Property(e => e.SeizoensId).IsRequired(false);
                entity.Property(e => e.Hoofdpunten).HasDefaultValue(0);
                entity.Property(e => e.PlusMinPunten).HasDefaultValue(0);
                entity.Property(e => e.SpelerNaam).IsRequired(false);
                entity.Property(e => e.SpelerVoornaam).IsRequired(false);
            });

            // Spelverdeling - make SpelerPositie optional for tests
            modelBuilder.Entity<Spelverdeling>(entity =>
            {
                entity.HasKey(e => e.SpelverdelingsId);
                entity.Property(e => e.SpelverdelingsId);
                entity.Property(e => e.SpelId).IsRequired(false);
                entity.Property(e => e.SpelerId).IsRequired(false);
                entity.Property(e => e.Team).IsRequired(false);
                entity.Property(e => e.SpelerPositie).IsRequired(false);
                // SpelerVolgnr is an int (non-nullable) in the production model; mark a default value for tests
                entity.Property(e => e.SpelerVolgnr).HasDefaultValue(0);
            });

            // Spel and others: minimal keys so relations work if used in tests
            modelBuilder.Entity<Spel>(entity => { entity.HasKey(e => e.SpelId); entity.Property(e => e.SpelId); });

            // Do NOT call base.OnModelCreating(modelBuilder) - production mappings would overwrite test config
         }
     }
 }
