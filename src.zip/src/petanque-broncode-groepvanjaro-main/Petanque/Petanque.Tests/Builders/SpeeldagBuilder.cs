﻿using Petanque.Contracts.Responses;

namespace Petanque.Tests.Builders
{
    public class SpeeldagBuilder
    {
        private int _speeldagId = 42;
        private readonly List<SpelResponseContract> _spellen = new();

        public SpeeldagBuilder MetId(int id) { _speeldagId = id; return this; }
        public SpeeldagBuilder MetSpel(SpelResponseContract spel) { _spellen.Add(spel); return this; }

        public SpeeldagResponseContract Build() => new()
        {
            SpeeldagId = _speeldagId,
            Datum = DateTime.Today,
            Seizoenen = null,
            Spel = _spellen
        };

    }
}
