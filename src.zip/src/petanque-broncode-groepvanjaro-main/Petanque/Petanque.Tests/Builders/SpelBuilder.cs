﻿using Petanque.Contracts.Responses;

namespace Petanque.Tests.Builders
{
    public class SpelBuilder
    {
        private int _spelId;
        private int? _speeldagId;
        private string _terrein = "T1";
        private int _scoreA;
        private int _scoreB;
        private readonly List<SpelverdelingResponseContract> _verd = new();

        public SpelBuilder MetIds(int spelId, int speeldagId)
        { _spelId = spelId; _speeldagId = speeldagId; return this; }

        public SpelBuilder Score(int a, int b)
        { _scoreA = a; _scoreB = b; return this; }

        public SpelBuilder TeamA(params int[] spelersVolgnr)
        {
            foreach (var v in spelersVolgnr)
                _verd.Add(new SpelverdelingResponseContract
                {
                    SpelverdelingsId = 0,
                    SpelId = _spelId,
                    Team = "Team A",
                    SpelerPositie = "?",
                    SpelerVolgnr = v
                });
            return this;
        }

        public SpelBuilder TeamB(params int[] spelersVolgnr)
        {
            foreach (var v in spelersVolgnr)
                _verd.Add(new SpelverdelingResponseContract
                {
                    SpelverdelingsId = 0,
                    SpelId = _spelId,
                    Team = "Team B",
                    SpelerPositie = "?",
                    SpelerVolgnr = v
                });
            return this;
        }

        public SpelResponseContract Build() => new()
        {
            SpelId = _spelId,
            SpeeldagId = _speeldagId,
            Terrein = _terrein,
            ScoreA = _scoreA,
            ScoreB = _scoreB,
            Spelverdelingen = _verd
        };

    }
}
