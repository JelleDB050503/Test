using System;
using System.Collections.Generic;
using System.Linq;
using Petanque.Contracts.Responses;
using Petanque.Services.Services;
using Petanque.Storage;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Petanque.Tests
{
    public class SpelverdelingPDFServiceTests
    {
        static SpelverdelingPDFServiceTests()
        {
            QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;
        }

        private Id312896PetanqueContext GetInMemoryContext()
        {
            var options = new DbContextOptionsBuilder<Id312896PetanqueContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new TestPetanqueContext(options);
        }

        [Fact]
        public void ReturnsStream_WhenDataExists()
        {
            using var context = GetInMemoryContext();
            
            context.Spelverdelings.AddRange(new List<Spelverdeling>
            {
                new Spelverdeling { SpelerId = 1, SpelId = 1, Team = "A" },
                new Spelverdeling { SpelerId = 2, SpelId = 1, Team = "B" }
            });
            context.SaveChanges();
            
            var service = new SpelverdelingPDFService(context);

            var spelContract = new SpelResponseContract
            {
                SpelId = 1,
                SpeeldagId = 1,
                Terrein = "Terrein 1",
                ScoreA = 0,
                ScoreB = 0,
                Spelverdelingen = new System.Collections.Generic.List<SpelverdelingResponseContract>()
            };

            context.Speeldags.Add(new Speeldag { SpeeldagId = 1, Datum = DateTime.Now, SeizoensId = 1 });
            context.SaveChanges();
            
            var contracts = new System.Collections.Generic.List<SpelverdelingResponseContract>
            {
                new SpelverdelingResponseContract { SpelId = 1, Team = "Team A", SpelerVolgnr = 1, Spel = spelContract },
                new SpelverdelingResponseContract { SpelId = 1, Team = "Team B", SpelerVolgnr = 2, Spel = spelContract }
            };
            spelContract.Spelverdelingen = contracts;

            var pdfStream = service.GenerateSpelverdelingPDF(contracts);

            Assert.NotNull(pdfStream);
            Assert.True(pdfStream.Length > 0);
        }

        [Fact]
        public void ThrowsException_WhenSpeeldagIdNull()
        {
            using var context = GetInMemoryContext();
            var service = new SpelverdelingPDFService(context);

            Assert.Throws<InvalidOperationException>(() => service.GenerateSpelverdelingPDF(new List<SpelverdelingResponseContract>()));
        }
    }
}
