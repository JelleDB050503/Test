﻿using Xunit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Petanque.Services.Services;
using Petanque.Contracts.Responses;
using Petanque.Storage;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Petanque.Tests;

public class SpelVerdelingServiceTest
{
    private SpelverdelingService CreateService()
    {
        var options = new DbContextOptionsBuilder<Id312896PetanqueContext>()
            .UseInMemoryDatabase(databaseName: "TestDB_" + Guid.NewGuid())
            .Options;

        var context = new Id312896PetanqueContext(options);
        var logger = new NullLogger<SpelverdelingService>();
        return new SpelverdelingService(context, logger);
    }

    [Fact]
    public void MaakVerdeling_Met8Spelers_MaaktCorrectAantalTeams()
    {
        // Arrange
        var service = CreateService();

        var aanwezigheden = Enumerable.Range(1, 8)
            .Select(i => new AanwezigheidResponseContract { SpelerVolgnr = i })
            .ToList();

        // Act
        var result = service.MaakVerdeling(aanwezigheden, speeldagId: 1).ToList();

        // Assert
        Assert.NotEmpty(result);
        Assert.True(result.All(r => r.SpelId > 0));

        // Controleer dat er minstens 1 spel is
        Assert.True(result.GroupBy(r => r.SpelId).Count() > 0);

        // Alle spelers uit aanwezigheden moeten minstens één keer voorkomen
        var alleSpelersInResultaat = result.Select(r => r.SpelerVolgnr).Distinct().ToList();
        foreach (var speler in aanwezigheden.Select(a => a.SpelerVolgnr))
        {
            Assert.Contains(speler, alleSpelersInResultaat);
        }
    }

    [Fact]
    public void VerwijderOudeSpellen_VerwijdertDataCorrect()
    {
        // Arrange
        var service = CreateService();

        // Reflecteer context uit de service
        var contextField = typeof(SpelverdelingService)
            .GetField("_context", BindingFlags.NonPublic | BindingFlags.Instance);
        var context = (Id312896PetanqueContext)contextField.GetValue(service)!;

        int speeldagId = 99;

        // Voeg dummydata toe
        context.Spels.Add(new Spel { SpelId = 1, SpeeldagId = speeldagId, Terrein = "Terrein 1" });
        context.Spelverdelings.Add(new Spelverdeling
        {
            SpelverdelingsId = 1,
            SpelId = 1,
            SpelerPositie = "P1",
            Team = "Team A"
        });
        context.SaveChanges();

        // Act: probeer eerst via public method, val terug op private als die niet bestaat
        var method = typeof(SpelverdelingService).GetMethod("VerwijderOudeSpellen",
            BindingFlags.NonPublic | BindingFlags.Instance);

        if (method != null)
        {
            // Originele code: private VerwijderOudeSpellen
            method.Invoke(service, new object[] { speeldagId });
        }
        else
        {
            // Gerefactorde code: Delete gebeurt intern in MaakVerdeling
            service.MaakVerdeling(
                new List<AanwezigheidResponseContract> {
                    new() { SpelerVolgnr = 1 },
                    new() { SpelerVolgnr = 2 },
                    new() { SpelerVolgnr = 3 },
                    new() { SpelerVolgnr = 4 }
                },
                speeldagId
            );
        }

        // Assert
        Assert.Empty(context.Spels.Where(s => s.SpeeldagId == speeldagId));
        Assert.Empty(context.Spelverdelings);
    }

    [Fact]
    public void MaakVerdeling_OngeldigAantalAanwezigheden_ThrowsException()
    {
        // Arrange
        var service = CreateService();
        IEnumerable<AanwezigheidResponseContract> aanwezigheden = null;

        // Act & Assert
        Assert.Throws<InvalidOperationException>(() =>
            service.MaakVerdeling(aanwezigheden, speeldagId: 1));
    }

    [Fact]
    public void MaakVerdeling_LegeLijstAantalAanwezigheden_ThrowsException()
    {
        // Arrange
        var service = CreateService();
        var aanwezigheden = new List<AanwezigheidResponseContract>();

        // Act & Assert
        var exception = Assert.Throws<InvalidOperationException>(() =>
        service.MaakVerdeling(aanwezigheden, speeldagId: 1));

        Assert.Equal("Er zijn nog geen aanwezigen aangeduid op deze speeldag", exception.Message);
    }

    [Fact]
    public void MaakVerdeling_DubbeleSpelers_ThrowsException()
    {
        // Arrange
        var service = CreateService();

        var aanwezigheden = new List<AanwezigheidResponseContract>
            {
                new AanwezigheidResponseContract { SpelerVolgnr = 1 }, // Dubbel
                new AanwezigheidResponseContract { SpelerVolgnr = 2 },
                new AanwezigheidResponseContract { SpelerVolgnr = 3 },
                new AanwezigheidResponseContract { SpelerVolgnr = 4 },
                new AanwezigheidResponseContract { SpelerVolgnr = 1 }    // Dubbel
            };

        // Act & Assert
        Assert.Throws<InvalidOperationException>(() =>
            service.MaakVerdeling(aanwezigheden, speeldagId: 1));
    }     

    [Fact]
    public void MaakVerdeling_SchrijftDataCorrectWeg()
    {
        // Arrange
        var service = CreateService();

        int speeldagId = 1;

        // Lijst van aanwezige spelers
        var aanwezigheden = Enumerable.Range(1, 8)
            .Select(i => new AanwezigheidResponseContract { SpelerVolgnr = i })
            .ToList();

        // Act: maak de verdeling via de publieke methode
        var result = service.MaakVerdeling(aanwezigheden, speeldagId).ToList();

        // Haal de private context via reflection (alleen om DB te controleren)
        var contextField = typeof(SpelverdelingService)
            .GetField("_context", BindingFlags.NonPublic | BindingFlags.Instance);
        var context = (Id312896PetanqueContext)contextField.GetValue(service)!;

        // Assert: controleer dat de context data bevat
        Assert.NotEmpty(context.Spels);
        Assert.NotEmpty(context.Spelverdelings);

        // Controleer dat alle spelers aanwezig zijn in de verdeling
        foreach (var spelerId in aanwezigheden.Select(a => a.SpelerVolgnr))
        {
            Assert.Contains(context.Spelverdelings, s => s.SpelerVolgnr == spelerId);
        }

        // Controleer dat alle spellen een SpelId hebben
        Assert.All(result, r => Assert.True(r.SpelId > 0));

        // Controleer dat alle spelers minstens één keer in een spel voorkomen
        var alleSpelersInResultaat = result.Select(r => r.SpelerVolgnr).Distinct();
        foreach (var speler in aanwezigheden.Select(a => a.SpelerVolgnr))
        {
            Assert.Contains(speler, alleSpelersInResultaat);
        }
    }
}
