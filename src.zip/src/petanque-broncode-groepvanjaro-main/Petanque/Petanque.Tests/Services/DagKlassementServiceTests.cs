﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Petanque.Contracts.Responses;
using Petanque.Services.Services;
using Petanque.Storage;
using Petanque.Tests.Builders;
using System.Linq;
using Xunit;

namespace Petanque.Tests.Services
{
    public class DagKlassementServiceTest
    {
        // 🧱 Helper: InMemory-DbContext per test (geïsoleerd)
        private static Id312896PetanqueContext MaakInMemoryContext()
        {
            var options = new DbContextOptionsBuilder<Id312896PetanqueContext>()
                .UseInMemoryDatabase("PetanqueTest_" + Guid.NewGuid().ToString("N"))
                // voorkom transactie-warnings die tot exceptions kunnen leiden
                .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            return new Id312896PetanqueContext(options);

        }

        [Fact]
        public void MaakDagklassement_MetAanwezigenEnSpellen_BerekeningIsCorrect()
        {
            // Arrange
            const int speeldagId = 42;
            using var context = MaakInMemoryContext();

            // Aanwezigheden (mapping volgnr -> spelerId)
            context.Aanwezigheids.AddRange(
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 1, SpelerId = 101 },
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 2, SpelerId = 102 },
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 3, SpelerId = 103 },
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 4, SpelerId = 104 } // niet gebruikt
            );
            context.SaveChanges();

            // 3 spellen met verschillende resultaten
            var spel1 = new SpelBuilder().MetIds(1, speeldagId).TeamA(1, 2).TeamB(3).Score(13, 7).Build();  // A wint (+6)
            var spel2 = new SpelBuilder().MetIds(2, speeldagId).TeamA(3).TeamB(1, 2).Score(5, 13).Build();   // B wint (+8)
            var spel3 = new SpelBuilder().MetIds(3, speeldagId).TeamA(2).TeamB(3).Score(13, 6).Build();      // A wint (+7)

            var speeldag = new SpeeldagBuilder().MetId(speeldagId)
                .MetSpel(spel1).MetSpel(spel2).MetSpel(spel3)
                .Build();

            var service = new DagKlassementService(context);

            // Act
            var resultaat = service.CreateDagKlassementen(speeldag, speeldagId).ToList();

            // Assert – enkel spelers die effectief meespeelden
            Assert.Equal(3, resultaat.Count);
            Assert.DoesNotContain(resultaat, r => r.SpelerId == 104);
            Assert.All(resultaat, r => Assert.Equal(speeldagId, r.SpeeldagId));

            // Controle van berekende waarden:
            // p1: +6 (win) +8 (win) = +14, wins=2
            // p2: +6 (win) +8 (win) +7 (win) = +21, wins=3
            // p3: -6 -8 -7 = -21, wins=0
            var p1 = resultaat.Single(r => r.SpelerId == 101);
            var p2 = resultaat.Single(r => r.SpelerId == 102);
            var p3 = resultaat.Single(r => r.SpelerId == 103);

            Assert.Equal(+14, p1.PlusMinPunten);
            Assert.Equal(3, p1.Hoofdpunten);

            Assert.Equal(+21, p2.PlusMinPunten);
            Assert.Equal(4, p2.Hoofdpunten);

            Assert.Equal(-21, p3.PlusMinPunten);
            Assert.Equal(1, p3.Hoofdpunten);
        }

        [Fact]
        public void MaakDagklassement_ZonderSpellen_GeeftLeegResultaat()
        {
            // Arrange
            const int speeldagId = 99;
            using var context = MaakInMemoryContext();

            context.Aanwezigheids.AddRange(
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 1, SpelerId = 1001 },
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 2, SpelerId = 1002 }
            );
            context.SaveChanges();

            var speeldag = new SpeeldagBuilder().MetId(speeldagId).Build();
            var service = new DagKlassementService(context);

            // Act
            var resultaat = service.CreateDagKlassementen(speeldag, speeldagId);

            // Assert
            Assert.Empty(resultaat);
        }

        [Fact]
        public void MaakDagklassement_BijGelijkspel_GeeftGeenWinEnSaldoNul()
        {
            // Arrange
            const int speeldagId = 77;
            using var context = MaakInMemoryContext();

            context.Aanwezigheids.AddRange(
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 1, SpelerId = 5001 },
                new Aanwezigheid { SpeeldagId = speeldagId, SpelerVolgnr = 2, SpelerId = 5002 }
            );
            context.SaveChanges();

            var spel = new SpelBuilder().MetIds(1, speeldagId).TeamA(1).TeamB(2).Score(10, 10).Build(); // gelijkspel
            var speeldag = new SpeeldagBuilder().MetId(speeldagId).MetSpel(spel).Build();
            var service = new DagKlassementService(context);

            // Act
            var resultaat = service.CreateDagKlassementen(speeldag, speeldagId).ToList();

            // Assert – 2 entries, geen winst, saldo 0
            Assert.Equal(2, resultaat.Count);

            var a = resultaat.Single(r => r.SpelerId == 5001);
            var b = resultaat.Single(r => r.SpelerId == 5002);

            Assert.Equal(1, a.Hoofdpunten);
            Assert.Equal(1, b.Hoofdpunten);
            Assert.Equal(0, a.PlusMinPunten);
            Assert.Equal(0, b.PlusMinPunten);
        }
    }
}