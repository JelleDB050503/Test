using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Petanque.Services;
using Petanque.Services.Services;
using Petanque.Storage;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Petanque.Tests
{
    public class DagKlassementPDFServiceTests
    {
        static DagKlassementPDFServiceTests()
        {
            QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;
        }

        private Id312896PetanqueContext GetContext()
        {
            var options = new DbContextOptionsBuilder<Id312896PetanqueContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
            return new TestPetanqueContext(options);
        }

        [Fact]
        public async Task ReturnsStream_WhenDataExists()
        {
            using var context = GetContext();
            
            context.Speeldags.Add(new Speeldag { SpeeldagId = 1, Datum = DateTime.Now, SeizoensId = 1 });
            context.Spelers.AddRange(new List<Speler>
            {
                new Speler { SpelerId = 1, Naam = "Naam1", Voornaam = "Voor1" },
                new Speler { SpelerId = 2, Naam = "Naam2", Voornaam = "Voor2" }
            });
            await context.SaveChangesAsync();

            context.Dagklassements.AddRange(new List<Dagklassement>
            {
                new Dagklassement { SpelerId = 1, SpeeldagId = 1, PlusMinPunten = 10 },
                new Dagklassement { SpelerId = 2, SpeeldagId = 1, PlusMinPunten = 12 }
            });
            await context.SaveChangesAsync();

            var service = new DagKlassementPDFService(context);

            var pdfStream = await service.GenerateDagKlassementPdfAsync(1);

            Assert.NotNull(pdfStream);
            Assert.True(pdfStream.Length > 0);
        }

        [Fact]
        public void ThrowsException_WhenSpeeldagIdNull()
        {
            using var context = GetContext();
            var service = new DagKlassementPDFService(context);

            Assert.ThrowsAsync<InvalidOperationException>(async () => await service.GenerateDagKlassementPdfAsync(0));
        }
    }
}