using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Petanque.Services.Services;
using Petanque.Storage;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Petanque.Tests
{
    public class SeizoensKlassementPDFServiceTests
    {
        static SeizoensKlassementPDFServiceTests()
        {
            QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;
        }

        private Id312896PetanqueContext GetContext()
        {
            var options = new DbContextOptionsBuilder<Id312896PetanqueContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
            return new TestPetanqueContext(options);
        }

        [Fact]
        public async Task ReturnsStream_WhenDataExists()
        {
            using var context = GetContext();

            context.Seizoensklassements.AddRange(new List<Seizoensklassement>
            {
                new Seizoensklassement { SpelerId = 1, SeizoensId = 1, PlusMinPunten = 20 },
                new Seizoensklassement { SpelerId = 2, SeizoensId = 1, PlusMinPunten = 18 }
            });
            await context.SaveChangesAsync();

            var service = new SeizoensKlassementPDFService(context);

            var pdfStream = await service.GenerateSeizoensKlassementPdfAsync(1);

            Assert.NotNull(pdfStream);
            Assert.True(pdfStream.Length > 0);
        }

        [Fact]
        public async Task ReturnsNull_WhenNoSeizoensklassements()
        {
            using var context = GetContext();

            var service = new SeizoensKlassementPDFService(context);

            var pdfStream = await service.GenerateSeizoensKlassementPdfAsync(999);

            Assert.Null(pdfStream);
        }
    }
}