using System;
using System.Collections.Generic;
using Petanque.Contracts.Responses;

namespace Petanque.Services.Models
{
    public class SpelverdelingPdfModel
    {
        public int SpeeldagId { get; set; }
        public DateTime Datum { get; set; }
        public List<SpelPdf> Spellen { get; set; } = new();

        public class SpelPdf
        {
            public int SpelId { get; set; }
            public int? SpeeldagId { get; set; }
            public string Terrein { get; set; } = string.Empty;
            public int? ScoreA { get; set; }
            public int? ScoreB { get; set; }
            public List<SpelverdelingResponseContract> Spelverdelingen { get; set; } = new();
        }
    }
}

