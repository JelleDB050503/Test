namespace Petanque.Services.Models;

public class SeizoensKlassementPdfModel
{
    public int SeizoenId { get; set; }
    public string SeizoenNaam { get; set; } = string.Empty;
    public List<SeizoensKlassementRow> Rows { get; set; } = new();

    public class SeizoensKlassementRow
    {
        public int? Rank { get; set; }
        public string Naam { get; set; } = string.Empty;
        public string Voornaam { get; set; } = string.Empty;
        public int Hoofdpunten { get; set; }
        public int PlusMinPunten { get; set; }
    }
}