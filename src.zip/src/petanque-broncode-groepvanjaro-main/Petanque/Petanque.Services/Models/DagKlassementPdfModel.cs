using System;
using System.Collections.Generic;

namespace Petanque.Services.Models
{
    public class DagKlassementPdfModel
    {
        public int SpeeldagId { get; set; }
        public DateTime Datum { get; set; }
        public List<DagKlassementRow> Rows { get; set; } = new();

        public class DagKlassementRow
        {
            public int? Rank { get; set; }
            public string Naam { get; set; } = string.Empty;
            public string Voornaam { get; set; } = string.Empty;
            public int Hoofdpunten { get; set; }
            public int Score { get; set; }
        }
    }
}

