using Petanque.Services.Interfaces;
using QuestPDF.Fluent;

namespace Petanque.Services.Services;

public class QuestPdfGenerator : IPdfGenerator
{
    public Stream Generate<TModel>(TModel model, IDocumentFactory<TModel> factory, CancellationToken ct = default)
    {
        var document = factory.CreateDocument(model);
        var stream = new MemoryStream();
        document.GeneratePdf(stream);
        stream.Position = 0;
        return stream;
    }
}