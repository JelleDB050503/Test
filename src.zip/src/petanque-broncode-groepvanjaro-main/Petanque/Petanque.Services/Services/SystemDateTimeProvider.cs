using System.Globalization;
using Microsoft.Extensions.Options;
using Petanque.Services.Interfaces;
using Petanque.Services.Options;

namespace Petanque.Services.Services;

public class SystemDateTimeProvider : IDateTimeProvider
{
    private readonly PdfOptions _options;

    public SystemDateTimeProvider(IOptions<PdfOptions> options)
    {
        _options = options.Value;
    }

    public DateTime Now => DateTime.Now;

    public string Format(DateTime dt, string format)
    {
        var culture = new CultureInfo(_options.Culture);
        return dt.ToString(format, culture);
    }
}