﻿using Petanque.Services.Interfaces;
using Petanque.Services.Models;
using Petanque.Services.Factories;
using Petanque.Services.Options;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Petanque.Storage;
using Petanque.Services.Repositories;
using Microsoft.Extensions.Options;

namespace Petanque.Services.Services
{
    public class SeizoensKlassementPDFService : ISeizoensKlassementPDFService
    {
        private readonly IKlassementRepository _repository;
        private readonly IPdfGenerator _pdfGenerator;
        private readonly PdfOptions _options;
        private readonly IDateTimeProvider _dateTimeProvider;
        
        
        // --- old compatibility constructor (used in tests) ---
        /*public SeizoensKlassementPDFService(Id312896PetanqueContext context)
        {
            _repository = new KlassementRepository(context); // simple wrapper over EF context
            _pdfGenerator = new QuestPdfGenerator();          // basic default implementation
            _options = new PdfOptions();
            _dateTimeProvider = new SystemDateTimeProvider(new OptionsWrapper<PdfOptions>(_options));
        }*/

        public SeizoensKlassementPDFService(
            IKlassementRepository repository,
            IPdfGenerator pdfGenerator,
            PdfOptions options,
            IDateTimeProvider dateTimeProvider)
        {
            _repository = repository;
            _pdfGenerator = pdfGenerator;
            _options = options;
            _dateTimeProvider = dateTimeProvider;
        }

        public async Task<Stream?> GenerateSeizoensKlassementPdfAsync(int seizoenId, CancellationToken ct = default)
        {
            var entities = await _repository.GetSeizoensklassementBySeasonAsync(seizoenId, ct);
            if (entities == null || !entities.Any())
            {
                return null;
            }

            var model = new SeizoensKlassementPdfModel
            {
                SeizoenId = seizoenId,
                Rows = entities.Select((k, idx) => new SeizoensKlassementPdfModel.SeizoensKlassementRow
                {
                    Rank = idx + 1, // simple rank, could apply tie logic
                    Naam = k.SpelerNaam,
                    Voornaam = k.SpelerVoornaam,
                    Hoofdpunten = k.Hoofdpunten,
                    PlusMinPunten = k.PlusMinPunten
                }).ToList()
            };

            var factory = new SeizoensKlassementDocumentFactory(_options, _dateTimeProvider);
            return _pdfGenerator.Generate(model, factory, ct);
        }
    }
}
