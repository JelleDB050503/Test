﻿using Microsoft.EntityFrameworkCore;
using Petanque.Contracts.Requests;
using Petanque.Contracts.Responses;
using Petanque.Services.Interfaces;
using Petanque.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petanque.Services.Services
{
    public class DagKlassementService(Id312896PetanqueContext context) : IDagKlassementService
    {
        public DagKlassementResponseContract Create(DagKlassementRequestContract request)
        {
            var entity = new Dagklassement()
            {
                SpeeldagId = request.SpeeldagId,
                Hoofdpunten = request.Hoofdpunten,
                PlusMinPunten = request.PlusMinPunten,
                SpelerId = request.SpelerId
            };

            context.Dagklassements.Add(entity);
            context.SaveChanges();

            return MapToContract(entity);
        }

        public IEnumerable<DagKlassementResponseContract>? GetById(int id)
        {
            var dagklassementen = context.Dagklassements
            .Where(d => d.SpeeldagId == id)
            .ToList();

            return dagklassementen
                .Select(MapToContract)
                .Where(contract => contract != null)
                .ToList()!;
        }
        public IEnumerable<DagKlassementResponseContract> CreateDagKlassementen(SpeeldagResponseContract speeldagData, int id)
        {
            var speeldagId = speeldagData.SpeeldagId;

            var gebruikteVolgnrs = BepaalGebruikteVolgnummers(speeldagData);
            var spelersInSpeeldag = HaalAanwezighedenOp(speeldagId, gebruikteVolgnrs);

            var scorePerSpeler = new Dictionary<int, int>();
            var winsPerSpeler = new Dictionary<int, int>();

            BerekenScores(speeldagData, scorePerSpeler, winsPerSpeler);

            var dagKlassementen = BouwDagKlassementen(speeldagId, spelersInSpeeldag, scorePerSpeler, winsPerSpeler);
            var entities = dagKlassementen.Select(MapToEntity).ToList();

            BewaarDagKlassementen(speeldagId, entities);

            return dagKlassementen;
        }

        // Private helpers met SRP

        private static List<int> BepaalGebruikteVolgnummers(SpeeldagResponseContract speeldagData)
        {
            return speeldagData.Spel
                .SelectMany(s => s.Spelverdelingen ?? [])
                .Select(sv => sv.SpelerVolgnr)
                .Distinct()
                .ToList();
        }

        private Dictionary<int, int> HaalAanwezighedenOp(int speeldagId, List<int> gebruikteVolgnrs)
        {
            return context.Aanwezigheids
                .Where(x => x.SpeeldagId == speeldagId && gebruikteVolgnrs.Contains(x.SpelerVolgnr))
                .AsEnumerable()
                .GroupBy(x => x.SpelerVolgnr)
                .ToDictionary(g => g.Key, g => g.First().SpelerId ?? 0); // null-safe
        }

        private static void BerekenScores(
            SpeeldagResponseContract speeldagData,
            Dictionary<int, int> scorePerSpeler,
            Dictionary<int, int> winsPerSpeler)
        {
            foreach (var spel in speeldagData.Spel)
            {
                if (spel?.Spelverdelingen == null || spel.Spelverdelingen.Count == 0)
                    continue;

                var teamA = spel.Spelverdelingen
                    .Where(v => v.Team == "Team A")
                    .Select(v => v.SpelerVolgnr)
                    .ToList();

                var teamB = spel.Spelverdelingen
                    .Where(v => v.Team == "Team B")
                    .Select(v => v.SpelerVolgnr)
                    .ToList();

                if (teamA.Count == 0 || teamB.Count == 0)
                    continue;

                var scoreA = spel.ScoreA;
                var scoreB = spel.ScoreB;
                var scoreVerschil = scoreA - scoreB;

                foreach (var speler in teamA)
                {
                    if (!scorePerSpeler.ContainsKey(speler)) scorePerSpeler[speler] = 0;
                    scorePerSpeler[speler] += scoreVerschil;

                    if (scoreA > scoreB)
                    {
                        if (!winsPerSpeler.ContainsKey(speler)) winsPerSpeler[speler] = 0;
                        winsPerSpeler[speler]++;
                    }
                }

                foreach (var speler in teamB)
                {
                    if (!scorePerSpeler.ContainsKey(speler)) scorePerSpeler[speler] = 0;
                    scorePerSpeler[speler] -= scoreVerschil;

                    if (scoreB > scoreA)
                    {
                        if (!winsPerSpeler.ContainsKey(speler)) winsPerSpeler[speler] = 0;
                        winsPerSpeler[speler]++;
                    }
                }
            }
        }

        private static List<DagKlassementResponseContract> BouwDagKlassementen(

            int speeldagId,
            Dictionary<int, int> spelersInSpeeldag,
            Dictionary<int, int> scorePerSpeler,
            Dictionary<int, int> winsPerSpeler)
        {
            var dagKlassementen = new List<DagKlassementResponseContract>();

            foreach (var (spelerVolgNr, spelerId) in spelersInSpeeldag)
            {
                var plusMin = scorePerSpeler.TryGetValue(spelerVolgNr, out var punten) ? punten : 0;
                var gewonnenSpellen = winsPerSpeler.TryGetValue(spelerVolgNr, out var wins) ? wins : 0;

                dagKlassementen.Add(new DagKlassementResponseContract
                {
                    SpeeldagId = speeldagId,
                    SpelerId = spelerId,
                    Hoofdpunten = 1 + gewonnenSpellen, // huidig gedrag behouden
                    PlusMinPunten = plusMin
                });
            }

            return dagKlassementen;
        }

        private static Dagklassement MapToEntity(DagKlassementResponseContract k)
        {
            return new Dagklassement
            {
                SpeeldagId = k.SpeeldagId,
                SpelerId = k.SpelerId,
                Hoofdpunten = k.Hoofdpunten,
                PlusMinPunten = k.PlusMinPunten
            };
        }

        private void BewaarDagKlassementen(int speeldagId, List<Dagklassement> entities)
        {
            var teVerwijderenQuery = context.Dagklassements.Where(d => d.SpeeldagId == speeldagId);

            if (context.Database.IsRelational())
            {
                using var tx = context.Database.BeginTransaction();
                try
                {
                    teVerwijderenQuery.ExecuteDelete();
                    context.AddRange(entities);
                    context.SaveChanges();
                    tx.Commit();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
            else
            {
                // InMemory-provider: eerst delete + SaveChanges, dan pas insert + SaveChanges
                var teVerwijderen = teVerwijderenQuery.ToList();
                context.Dagklassements.RemoveRange(teVerwijderen);
                context.SaveChanges(); // belangrijk voor InMemory i.v.m. keys

                context.AddRange(entities);
                context.SaveChanges();
            }
        }

        private static DagKlassementResponseContract MapToContract(Dagklassement entity)
        {
            return new DagKlassementResponseContract
            {
                DagklassementId = entity.DagklassementId,
                SpeeldagId = entity.SpeeldagId,
                SpelerId = entity.SpelerId,
                Hoofdpunten = entity.Hoofdpunten,
                PlusMinPunten = entity.PlusMinPunten
            };
        }
    }
}

