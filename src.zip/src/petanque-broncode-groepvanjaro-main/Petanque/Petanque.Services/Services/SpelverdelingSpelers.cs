using System;
using Petanque.Contracts.Responses;
using Petanque.Storage;

namespace Petanque.Services.Logic;

public class SpelverdelingSpelers
{
    public static void ControleerInputVelden(
            IEnumerable<AanwezigheidResponseContract> aanwezigheden,
            int maxAantalTerreinen,
            int minAantalSpelersPerTeam,
            int maxAantalSpelersPerTeam,
            out List<int> masterSpelerList,
            out int aantalGebruikteTerreinen)
    {
        if (aanwezigheden == null)
            throw new InvalidOperationException("BUG: Aanwezigheden zijn null. Dit mag niet gebeuren.");

        masterSpelerList = aanwezigheden.Select(a => a.SpelerVolgnr).ToList();

        if (masterSpelerList.Distinct().Count() != masterSpelerList.Count())
            throw new InvalidOperationException("BUG: Er zitten dubbele 'SpelerVolgnr's in de lijst 'aanwezigheden'.");

        int aantalAanwezigen = masterSpelerList.Count();

        if (aantalAanwezigen == 0)
            throw new InvalidOperationException("Er zijn nog geen aanwezigen aangeduid op deze speeldag");

        if ((int)Math.Ceiling((double)aantalAanwezigen / maxAantalSpelersPerTeam / 2) > maxAantalTerreinen)
            throw new InvalidOperationException(
                $"Er zijn {maxAantalTerreinen} terreinen beschikbaar. " +
                $"Er is dus slechts plaats voor {maxAantalSpelersPerTeam * 2 * maxAantalTerreinen} van de {aantalAanwezigen} aanwezigen. " +
                $"(Verhoog evt. 'maxAantalSpelersPerTeam')");

        aantalGebruikteTerreinen = (int)Math.Floor((double)aantalAanwezigen / minAantalSpelersPerTeam / 2);

        if (aantalGebruikteTerreinen < 1)
            throw new InvalidOperationException(
                $"Er zijn slechts {aantalAanwezigen} aanwezigen. " +
                $"Dit is onvoldoende als je minstens {minAantalSpelersPerTeam} spelers per team wilt. " +
                $"(Verlaag evt. 'minAantalSpelersPerTeam')");

        if ((int)Math.Ceiling((double)aantalAanwezigen / aantalGebruikteTerreinen / 2) > maxAantalSpelersPerTeam)
            throw new InvalidOperationException(
                $"Met {aantalAanwezigen} aanwezigen kan er geen spelverdeling gemaakt worden met minstens {minAantalSpelersPerTeam} " +
                $"en maximaal {maxAantalSpelersPerTeam} spelers per team. (Verlaag evt. 'minAantalSpelersPerTeam' of verhoog 'maxAantalSpelersPerTeam')");
    }

    public static Dictionary<string, int> BerekenAantalSpelersPerTerreinPerTeam(
        int aantalGebruikteTerreinen,
        int minAantalSpelersPerTeam,
        int aantalAanwezigen)
    {
        var aantalSpelersPerTerreinPerTeam = new Dictionary<string, int>();
        int totaalAantalSpelers = 0;
        int terrein;

        for (terrein = 1; terrein <= aantalGebruikteTerreinen; terrein++)
        {
            aantalSpelersPerTerreinPerTeam[$"{terrein},A"] = minAantalSpelersPerTeam;
            aantalSpelersPerTerreinPerTeam[$"{terrein},B"] = minAantalSpelersPerTeam;
            totaalAantalSpelers += 2 * minAantalSpelersPerTeam;
        }

        if (totaalAantalSpelers > aantalAanwezigen)
            throw new InvalidOperationException($"BUG: totaalAantalSpelers={totaalAantalSpelers} > aantalAanwezigen={aantalAanwezigen}");

        terrein = 1;
        char team = 'A';
        while (totaalAantalSpelers < aantalAanwezigen)
        {
            aantalSpelersPerTerreinPerTeam[$"{terrein},{team}"]++;
            totaalAantalSpelers++;
            team++;
            if (team == 'C')
            {
                team = 'A';
                terrein++;
                if (terrein > aantalGebruikteTerreinen) terrein = 1;
            }
        }

        return aantalSpelersPerTerreinPerTeam;
    }

    public static List<SpelverdelingResponseContract> InsertSpellenEnVerdelingen(
        Id312896PetanqueContext context,
        int speeldagId,
        int aantalSpelrondes,
        int aantalGebruikteTerreinen,
        Dictionary<string, int> aantalSpelersPerTerreinPerTeam,
        Dictionary<string, int> spelverdelingsInfo)
    {
        var responses = new List<SpelverdelingResponseContract>();
        var nieuweSpellen = new List<Spel>();
        var nieuweSpelverdelingen = new List<Spelverdeling>();

        for (int spelronde = 1; spelronde <= aantalSpelrondes; spelronde++)
        {
            for (int terrein = 1; terrein <= aantalGebruikteTerreinen; terrein++)
            {
                var spel = new Spel
                {
                    SpeeldagId = speeldagId,
                    Terrein = $"Terrein {terrein}",
                    ScoreA = 0,
                    ScoreB = 0,
                    SpelerVolgnr = spelverdelingsInfo[$"{spelronde},{terrein},A,1"]
                };
                nieuweSpellen.Add(spel);

                foreach (char team in new[] { 'A', 'B' })
                {
                    for (int nrInTeam = 1; nrInTeam <= aantalSpelersPerTerreinPerTeam[$"{terrein},{team}"]; nrInTeam++)
                    {
                        int spelerVolgnr = spelverdelingsInfo[$"{spelronde},{terrein},{team},{nrInTeam}"];
                        nieuweSpelverdelingen.Add(new Spelverdeling
                        {
                            Spel = spel,
                            Team = $"Team {team}",
                            SpelerPositie = $"P{nrInTeam}",
                            SpelerVolgnr = spelerVolgnr,
                            SpelerId = spelerVolgnr
                        });
                    }
                }
            }
        }

        context.Spels.AddRange(nieuweSpellen);
        context.Spelverdelings.AddRange(nieuweSpelverdelingen);
        context.SaveChanges();

        responses.AddRange(nieuweSpelverdelingen.Select(MapToContract));
        return responses;
    }

    private static SpelverdelingResponseContract MapToContract(Spelverdeling entity)
    {
        return new SpelverdelingResponseContract
        {
            SpelverdelingsId = entity.SpelverdelingsId,
            SpelId = entity.SpelId,
            Team = entity.Team,
            SpelerPositie = entity.SpelerPositie,
            SpelerVolgnr = entity.SpelerVolgnr
        };
    }
}
