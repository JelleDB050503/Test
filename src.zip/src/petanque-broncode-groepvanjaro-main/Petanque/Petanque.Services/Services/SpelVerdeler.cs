using System;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Petanque.Services.Logic;

public class SpelVerdeler
{
    private readonly ILogger _logger;
        private readonly Random _random = new();

        public SpelVerdeler(ILogger logger)
        {
            _logger = logger;
        }

        private struct SmartDetails
        {
            public int Terrein;
            public List<int> TeamLeden;
            public List<int> Tegenspelers;
        }

       
        public (Dictionary<string, int> spelverdelingsInfo, int AantalGebruikteTerreinen, Dictionary<string, int> AantalSpelersPerTerreinPerTeam)
            MaakSpelverdeling(List<int> masterSpelerList, int aantalSpelrondes, int minAantalSpelersPerTeam, int maxAantalSpelersPerTeam, int maxAantalTerreinen)
        {
            // --- STAP 1: Bepaal terreinverdeling en teamsamenstelling ---
            if (masterSpelerList == null || masterSpelerList.Count == 0)
                throw new InvalidOperationException("Geen aanwezige spelers gevonden.");

            if (masterSpelerList.Distinct().Count() != masterSpelerList.Count)
                throw new InvalidOperationException("Dubbele spelerVolgnrs in masterSpelerList.");

            int aantalAanwezigen = masterSpelerList.Count;

            if ((int)Math.Ceiling((double)aantalAanwezigen / maxAantalSpelersPerTeam / 2) > maxAantalTerreinen)
                throw new InvalidOperationException($"Er zijn {maxAantalTerreinen} terreinen beschikbaar, maar te veel aanwezigen ({aantalAanwezigen}).");

            int aantalGebruikteTerreinen = (int)Math.Floor((double)aantalAanwezigen / minAantalSpelersPerTeam / 2);
            if (aantalGebruikteTerreinen < 1)
                throw new InvalidOperationException($"Onvoldoende spelers ({aantalAanwezigen}) voor minstens {minAantalSpelersPerTeam} spelers per team.");

            var aantalSpelersPerTerreinPerTeam = new Dictionary<string, int>();
            int totaalAantalSpelers = 0;
            int terrein = 1;

            // initieel minimum vullen
            for (terrein = 1; terrein <= aantalGebruikteTerreinen; terrein++)
            {
                aantalSpelersPerTerreinPerTeam[$"{terrein},A"] = minAantalSpelersPerTeam;
                aantalSpelersPerTerreinPerTeam[$"{terrein},B"] = minAantalSpelersPerTeam;
                totaalAantalSpelers += 2 * minAantalSpelersPerTeam;
            }

            // overblijvende spelers verdelen over teams
            terrein = 1; char teamChar = 'A';
            while (totaalAantalSpelers < aantalAanwezigen)
            {
                aantalSpelersPerTerreinPerTeam[$"{terrein},{teamChar}"]++;
                totaalAantalSpelers++;
                teamChar++;
                if (teamChar == 'C')
                {
                    teamChar = 'A';
                    terrein++;
                    if (terrein > aantalGebruikteTerreinen) terrein = 1;
                }
            }

            // --- STAP 2: Maak spelverdeling (zoals originele stap 2) ---
            var smartDetailsDictionary = new Dictionary<string, SmartDetails>();
            var spelverdelingsInfo = new Dictionary<string, int>();

            for (int spelronde = 1; spelronde <= aantalSpelrondes; spelronde++)
            {
                var beschikbareSpelers = new List<int>(masterSpelerList);
                var selectieVoorkeurScores = beschikbareSpelers.ToDictionary(n => n, n => 100);

                for (terrein = 1; terrein <= aantalGebruikteTerreinen; terrein++)
                {
                    var teamListDict = new Dictionary<char, List<int>>
                    {
                        ['A'] = new List<int>(),
                        ['B'] = new List<int>()
                    };

                    foreach (char team in new[] { 'A', 'B' })
                    {
                        char otherTeam = (team == 'A') ? 'B' : 'A';

                        if (spelronde > 1)
                            selectieVoorkeurScores = beschikbareSpelers.ToDictionary(n => n, n => 100);

                        for (int nrInTeam = 1; nrInTeam <= aantalSpelersPerTerreinPerTeam[$"{terrein},{team}"]; nrInTeam++)
                        {
                            // pas voorkeursscores aan op basis van eerdere rondes
                            for (int spelronde2 = 1; spelronde2 < spelronde; spelronde2++)
                            {
                                foreach (int speler in beschikbareSpelers)
                                {
                                    if (!smartDetailsDictionary.ContainsKey($"{spelronde2},{speler}"))
                                        continue;

                                    var details = smartDetailsDictionary[$"{spelronde2},{speler}"];

                                    if (nrInTeam == 1)
                                    {
                                        if (details.Terrein == terrein)
                                            selectieVoorkeurScores[speler] -= spelronde2;

                                        if (aantalSpelersPerTerreinPerTeam[$"{terrein},{team}"] > minAantalSpelersPerTeam)
                                        {
                                            if (details.TeamLeden.Count > minAantalSpelersPerTeam)
                                                selectieVoorkeurScores[speler] -= spelronde2 + 10;
                                            if (details.Tegenspelers.Count > minAantalSpelersPerTeam)
                                                selectieVoorkeurScores[speler] -= spelronde2 + 8;
                                        }

                                        if (aantalSpelersPerTerreinPerTeam[$"{terrein},{otherTeam}"] > minAantalSpelersPerTeam)
                                        {
                                            if (details.TeamLeden.Count > minAantalSpelersPerTeam)
                                                selectieVoorkeurScores[speler] -= spelronde2 + 8;
                                            if (details.Tegenspelers.Count > minAantalSpelersPerTeam)
                                                selectieVoorkeurScores[speler] -= spelronde2 + 6;
                                        }

                                        if (team == 'B')
                                        {
                                            foreach (int speler2 in teamListDict['A'])
                                            {
                                                if (details.TeamLeden.Contains(speler2))
                                                    selectieVoorkeurScores[speler] -= spelronde2 + 14;
                                                if (details.Tegenspelers.Contains(speler2))
                                                    selectieVoorkeurScores[speler] -= spelronde2 + 17;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        int vorigeSpeler = spelverdelingsInfo[$"{spelronde},{terrein},{team},{nrInTeam - 1}"];
                                        if (details.TeamLeden.Contains(vorigeSpeler))
                                            selectieVoorkeurScores[speler] -= spelronde2 + 20;
                                        if (details.Tegenspelers.Contains(vorigeSpeler))
                                            selectieVoorkeurScores[speler] -= spelronde2 + 14;
                                    }
                                }
                            }

                            int maxVal = selectieVoorkeurScores.Values.Max();
                            var kandidaten = selectieVoorkeurScores.Where(kvp => kvp.Value == maxVal).Select(kvp => kvp.Key).ToList();
                            int gekozen = kandidaten[_random.Next(kandidaten.Count)];

                            _logger.LogInformation($"[spelronde={spelronde}, terrein={terrein}, team={team}] speler={gekozen}, score={maxVal}");

                            beschikbareSpelers.Remove(gekozen);
                            selectieVoorkeurScores.Remove(gekozen);
                            spelverdelingsInfo[$"{spelronde},{terrein},{team},{nrInTeam}"] = gekozen;
                            teamListDict[team].Add(gekozen);
                        }
                    }

                    if (spelronde < aantalSpelrondes)
                    {
                        foreach (char team in new[] { 'A', 'B' })
                        {
                            char otherTeam = (team == 'A') ? 'B' : 'A';
                            foreach (int speler in teamListDict[team])
                            {
                                smartDetailsDictionary[$"{spelronde},{speler}"] = new SmartDetails
                                {
                                    Terrein = terrein,
                                    TeamLeden = new List<int>(teamListDict[team]),
                                    Tegenspelers = new List<int>(teamListDict[otherTeam])
                                };
                            }
                        }
                    }
                }
            }

            return (spelverdelingsInfo, aantalGebruikteTerreinen, aantalSpelersPerTerreinPerTeam);
        }
}
