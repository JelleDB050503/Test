using System;
using Microsoft.EntityFrameworkCore;
using Petanque.Services.Interfaces;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using QuestPDF.Fluent;
using QuestPDF.Infrastructure;
using Petanque.Storage;
using QuestPDF.Helpers;
using Petanque.Services.Repositories;
using Microsoft.Extensions.Options;
using Petanque.Services.Models;
using Petanque.Services.Factories;
using Petanque.Services.Options;

namespace Petanque.Services.Services
{
    public class DagKlassementPDFService : IDagKlassementPDFService
    {
        private readonly IDagKlassementRepository _repository;
        private readonly IPdfGenerator _pdfGenerator;
        private readonly PdfOptions _options;
        private readonly IDateTimeProvider _dateTimeProvider;
        
        // --- old compatibility constructor (used in tests) ---
        /*public DagKlassementPDFService(Id312896PetanqueContext context)
        {
            _repository = new DagKlassementRepository(context); // simple wrapper over EF context
            _pdfGenerator = new QuestPdfGenerator();          // basic default implementation
            _options = new PdfOptions();
            _dateTimeProvider = new SystemDateTimeProvider(new OptionsWrapper<PdfOptions>(_options));
        }*/
        
        public DagKlassementPDFService(IDagKlassementRepository repository, IPdfGenerator pdfGenerator, PdfOptions options, IDateTimeProvider dateTimeProvider)
        {
            _repository = repository;
            _pdfGenerator = pdfGenerator;
            _options = options;
            _dateTimeProvider = dateTimeProvider;
        }

        public async Task<Stream> GenerateDagKlassementPdfAsync(int id)
        {
            var speeldag = await _repository.GetSpeeldagByIdAsync(id);
            if (speeldag == null)
            {
                throw new InvalidOperationException($"Speeldag with id {id} was not found.");
            }

            var dagklassementsForSpeeldag = await _repository.GetDagklassementsBySpeeldagIdAsync(id);
            var spelerIdsInDagklassement = dagklassementsForSpeeldag
                .Select(d => d.SpelerId)
                .Where(idn => idn.HasValue)
                .Select(idn => idn!.Value)
                .ToList();

            var spelers = await _repository.GetSpelersByIdsAsync(spelerIdsInDagklassement);

            var dagklassements = dagklassementsForSpeeldag;

            if (dagklassements == null || !dagklassements.Any())
            {
                throw new InvalidOperationException($"No dagklassements found for speeldag with id {id}.");
            }

            // Build model for the factory
            var rows = spelers.Select((speler) =>
            {
                var dagKlassement = dagklassements.FirstOrDefault(dk => dk.SpelerId == speler.SpelerId);
                return new DagKlassementPdfModel.DagKlassementRow
                {
                    Naam = speler.Naam,
                    Voornaam = speler.Voornaam,
                    Hoofdpunten = dagKlassement?.Hoofdpunten ?? 0,
                    Score = dagKlassement?.PlusMinPunten ?? 0
                };
            })
            .OrderByDescending(r => r.Hoofdpunten)
            .ThenByDescending(r => r.Score)
            .ToList();

            var model = new DagKlassementPdfModel
            {
                SpeeldagId = id,
                Datum = speeldag.Datum,
                Rows = rows.Select((r, idx) => { r.Rank = idx + 1; return r; }).ToList()
            };

            var factory = new DagKlassementDocumentFactory(_options, _dateTimeProvider);
            return _pdfGenerator.Generate(model, factory);
        }


    }
}
