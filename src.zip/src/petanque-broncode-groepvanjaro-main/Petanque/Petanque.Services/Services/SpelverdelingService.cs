using Microsoft.EntityFrameworkCore;
using Petanque.Contracts.Responses;
using Petanque.Services.Interfaces;
using Petanque.Storage;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using System.Security.Cryptography.X509Certificates;
using System.Linq.Expressions;
using Petanque.Services.Logic;

namespace Petanque.Services.Services
{
    public class SpelverdelingService : ISpelverdelingService
    {
        private readonly Random _random = new();
        private readonly Id312896PetanqueContext _context;
        private readonly ILogger _logger;

        public SpelverdelingService(Id312896PetanqueContext context, ILogger<SpelverdelingService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IEnumerable<SpelverdelingResponseContract> GetById(int speeldagId)
        {
            var spellen = _context.Spels
                .Where(sp => sp.SpeeldagId == speeldagId)
                .ToList();

            if (!spellen.Any())
                return Enumerable.Empty<SpelverdelingResponseContract>();

            var spelIds = spellen.Select(s => s.SpelId).ToList();

            var spelverdelingen = _context.Spelverdelings
                .Where(sv => spelIds.Contains(sv.SpelId ?? 0))
                .ToList();

            var aanwezigheden = _context.Aanwezigheids
                .Include(a => a.Speler)
                .Where(a => a.SpeeldagId == speeldagId)
                .ToList();

            return spelverdelingen.Select(sv =>
            {
                var speler = aanwezigheden
                    .FirstOrDefault(a => a.SpelerVolgnr == sv.SpelerVolgnr)
                    ?.Speler;

                var spel = spellen.FirstOrDefault(sp => sp.SpelId == sv.SpelId);

                return MapToReturn(sv, speler, spel);
            }).ToList();
        }

        public struct smartDetails
        {
            public int Terrein;
            public List<int> TeamLeden, Tegenspelers;
        }
        public IEnumerable<SpelverdelingResponseContract> MaakVerdeling(IEnumerable<AanwezigheidResponseContract> aanwezigheden, int speeldagId)
        {
            _logger.LogCritical("Starting MaakVerdeling");

            const int maxAantalTerreinen = 10;
            const int aantalSpelrondes = 3;

            const int minAantalSpelersPerTeam = 2;
            const int maxAantalSpelersPerTeam = 3;

            int aantalGebruikteTerreinen; // aantal GEBRUIKTE terreinen
            List<int> masterSpelerList; // lijst van Volgnrs van aanwezige spelers
            Dictionary<string, int> aantalSpelersPerTerreinPerTeam; // key="terrein,team", value=aantalSpelers
            Dictionary<string, int> spelverdelingsInfo; // key="spelronde,terrein,team,nrInTeam", value=spelerVolgnr
            Dictionary<string, smartDetails> smartDetailsDictionary; // key="spelronde,spelerVolgnr", value="Terrein,TeamLeden,Tegenspelers"

            // STAP 1: Vul 'masterSpelerList', check aantal aanwezigen en terreinen, vul 'aantalSpelersPerTerreinPerTeam'
            {
                SpelverdelingSpelers.ControleerInputVelden(
               aanwezigheden,
               maxAantalTerreinen,
               minAantalSpelersPerTeam,
               maxAantalSpelersPerTeam,
               out masterSpelerList,
               out aantalGebruikteTerreinen);

                aantalSpelersPerTerreinPerTeam = SpelverdelingSpelers.BerekenAantalSpelersPerTerreinPerTeam(
                    aantalGebruikteTerreinen,
                    minAantalSpelersPerTeam,
                    masterSpelerList.Count);
            }
            // STAP 2: Spelverdeling maken (lokaal in Dictionary)
            {
                {

                    var verdeler = new Petanque.Services.Logic.SpelVerdeler(_logger);
                    (var SpelverdelingsInfo, var AantalGebruikteTerreinenVerdeler, var AantalSpelersPerTerreinPerTeamVerdeler) =
                        verdeler.MaakSpelverdeling(masterSpelerList, aantalSpelrondes, minAantalSpelersPerTeam, maxAantalSpelersPerTeam, maxAantalTerreinen);

                    // vervang lege dictionary door de output van SpelVerdeler
                    spelverdelingsInfo = SpelverdelingsInfo;
                    aantalGebruikteTerreinen = AantalGebruikteTerreinenVerdeler;
                    aantalSpelersPerTerreinPerTeam = AantalSpelersPerTerreinPerTeamVerdeler;

                }
            }
            // STAP 3: DELETE old Spel + Spelverdeling from DB
            {
                VerwijderOudeSpellen(speeldagId);
            }
            // STAP 4: INSERT content of (Dictionary) spelverdelingsInfo to DB
            {
                return SpelverdelingSpelers.InsertSpellenEnVerdelingen(
                _context,
                speeldagId,
                aantalSpelrondes,
                aantalGebruikteTerreinen,
                aantalSpelersPerTerreinPerTeam,
                spelverdelingsInfo
            );
            }
        }

        private void VerwijderOudeSpellen(int speeldagId)
        {
            //  Haal alle bestaande spel-IDs voor deze speeldag op
            var oudeSpelIds = _context.Spels
                .Where(sp => sp.SpeeldagId == speeldagId)
                .Select(sp => sp.SpelId)
                .ToList();

            if (!oudeSpelIds.Any())
            {
                _logger.LogInformation($"Geen oude spellen gevonden voor speeldag {speeldagId}.");
                return;
            }

            //  Verwijder gekoppelde spelverdelingen (child records)
            var oudeSpelverdelingen = _context.Spelverdelings
                .Where(sv => oudeSpelIds.Contains(sv.SpelId ?? 0))
                .ToList();

            if (oudeSpelverdelingen.Any())
            {
                _context.Spelverdelings.RemoveRange(oudeSpelverdelingen);
                _logger.LogInformation($"Verwijderd {oudeSpelverdelingen.Count} oude spelverdelingen.");
            }

            //  Verwijder de spellen zelf (parent records)
            var oudeSpellen = _context.Spels
                .Where(sp => sp.SpeeldagId == speeldagId)
                .ToList();

            if (oudeSpellen.Any())
            {
                _context.Spels.RemoveRange(oudeSpellen);
                _logger.LogInformation($"Verwijderd {oudeSpellen.Count} oude spellen.");
            }

            //  Commit naar database
            _context.SaveChanges();
            _logger.LogInformation($"Alle oude data voor speeldag {speeldagId} verwijderd.");
        }

        private static SpelverdelingResponseContract MapToContract(Spelverdeling entity)
        {
            return new SpelverdelingResponseContract
            {
                SpelverdelingsId = entity.SpelverdelingsId,
                SpelId = entity.SpelId,
                Team = entity.Team,
                SpelerPositie = entity.SpelerPositie,
                SpelerVolgnr = entity.SpelerVolgnr
            };
        }

        private static SpelverdelingResponseContract MapToReturn(Spelverdeling entity, Speler? speler, Spel? spel)
        {
            if (speler == null) throw new ArgumentNullException(nameof(speler), "Speler mag niet null zijn.");
            if (spel == null) throw new ArgumentNullException(nameof(spel), "Spel mag niet null zijn.");

            return new SpelverdelingResponseContract
            {
                SpelverdelingsId = entity.SpelverdelingsId,
                SpelId = entity.SpelId,
                Team = entity.Team,
                SpelerPositie = entity.SpelerPositie,
                SpelerVolgnr = entity.SpelerVolgnr,
                Speler = new PlayerResponseContract
                {
                    SpelerId = speler.SpelerId,
                    Voornaam = speler.Voornaam,
                    Naam = speler.Naam
                },
                Spel = new SpelResponseContract
                {
                    SpelId = spel.SpelId,
                    SpeeldagId = spel.SpeeldagId,
                    Terrein = spel.Terrein
                }
            };
        }
        public IEnumerable<SpelverdelingResponseContract> GetBySpeeldagAndTerrein(int speeldag, int terrein)
        {
            var spellen = _context.Spels
                .Where(sp => sp.SpeeldagId == speeldag && sp.Terrein == $"Terrein {terrein}")
                .ToList();

            if (!spellen.Any())
                return Enumerable.Empty<SpelverdelingResponseContract>();

            var spelIds = spellen.Select(s => s.SpelId).ToList();

            var spelverdelingen = _context.Spelverdelings
                .Where(sv => spelIds.Contains(sv.SpelId ?? 0))
                .ToList();

            var aanwezigheden = _context.Aanwezigheids
                .Include(a => a.Speler)
                .Where(a => a.SpeeldagId == speeldag)
                .ToList();

            return spelverdelingen.Select(sv =>
            {
                var speler = aanwezigheden
                    .FirstOrDefault(a => a.SpelerVolgnr == sv.SpelerVolgnr)
                    ?.Speler;

                var spel = spellen.FirstOrDefault(sp => sp.SpelId == sv.SpelId);

                return MapToReturn(sv, speler, spel);
            }).ToList();
        }
    }
}
