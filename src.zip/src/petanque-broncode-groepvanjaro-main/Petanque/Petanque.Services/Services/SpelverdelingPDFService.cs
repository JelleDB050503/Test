using System;
using Petanque.Contracts.Responses;
using Petanque.Services.Interfaces;
using Petanque.Storage;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using QuestPDF.Drawing;
using QuestPDF.Elements;
using Microsoft.EntityFrameworkCore;
using Petanque.Services.Repositories;
using Microsoft.Extensions.Options;
using Petanque.Services.Options;
using Petanque.Services.Models;
using Petanque.Services.Factories;

namespace Petanque.Services.Services
{
    public class SpelverdelingPDFService : ISpelverdelingPDFService
    {
        private readonly ISpelverdelingRepository _repository;
        private readonly IPdfGenerator _pdfGenerator;
        private readonly PdfOptions _options;
        private readonly IDateTimeProvider _dateTimeProvider;
        
        
        // --- old compatibility constructor (used in tests) ---
        /*public SpelverdelingPDFService(Id312896PetanqueContext context)
        {
            _repository = new SpelverdelingRepository(context); // simple wrapper over EF context
            _pdfGenerator = new QuestPdfGenerator();          // basic default implementation
            _options = new PdfOptions();
            _dateTimeProvider = new SystemDateTimeProvider(new OptionsWrapper<PdfOptions>(_options));
        }*/
        
        public SpelverdelingPDFService(ISpelverdelingRepository repository, IPdfGenerator pdfGenerator, PdfOptions options, IDateTimeProvider dateTimeProvider)
        {
            _repository = repository;
            _pdfGenerator = pdfGenerator;
            _options = options;
            _dateTimeProvider = dateTimeProvider;
        }

        public Stream GenerateSpelverdelingPDF(IEnumerable<SpelverdelingResponseContract> spelverdelingen)
        {
            if (spelverdelingen == null || !spelverdelingen.Any())
                throw new InvalidOperationException("SpeeldagId cannot be null.");

            int speeldagIdd = spelverdelingen.First().Spel.SpeeldagId ?? throw new InvalidOperationException("SpeeldagId cannot be null.");
            var speeldag = _repository.GetSpeeldagByIdAsync(speeldagIdd).GetAwaiter().GetResult();
            if (speeldag == null)
                throw new InvalidOperationException("SpeeldagId cannot be null.");

            // build model
            var spellen = spelverdelingen
                .GroupBy(sv => sv.SpelId)
                .Select(g =>
                {
                    var eerste = g.First();
                    return new SpelverdelingPdfModel.SpelPdf
                    {
                        SpelId = (int)eerste.SpelId,
                        SpeeldagId = eerste.Spel.SpeeldagId,
                        Terrein = eerste.Spel.Terrein,
                        ScoreA = eerste.Spel.ScoreA,
                        ScoreB = eerste.Spel.ScoreB,
                        Spelverdelingen = g.ToList()
                    };
                })
                .ToList();

            var model = new SpelverdelingPdfModel
            {
                SpeeldagId = speeldagIdd,
                Datum = speeldag.Datum,
                Spellen = spellen
            };

            var factory = new SpelverdelingDocumentFactory(_options, _dateTimeProvider);
            return _pdfGenerator.Generate(model, factory);
        }
    }
}
