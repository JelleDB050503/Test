using Petanque.Services.Interfaces;
using Petanque.Storage;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Petanque.Services.Repositories
{
    public class DagKlassementRepository : IDagKlassementRepository
    {
        private readonly Id312896PetanqueContext _context;

        public DagKlassementRepository(Id312896PetanqueContext context)
        {
            _context = context;
        }

        public async Task<Speeldag?> GetSpeeldagByIdAsync(int id, CancellationToken ct = default)
        {
            return await _context.Speeldags.FirstOrDefaultAsync(s => s.SpeeldagId == id, ct);
        }

        public async Task<List<Dagklassement>> GetDagklassementsBySpeeldagIdAsync(int speeldagId, CancellationToken ct = default)
        {
            return await _context.Dagklassements
                .Where(d => d.SpeeldagId == speeldagId)
                .ToListAsync(ct);
        }

        public async Task<List<Speler>> GetSpelersByIdsAsync(List<int> spelerIds, CancellationToken ct = default)
        {
            return await _context.Spelers
                .Where(sp => spelerIds.Contains(sp.SpelerId))
                .ToListAsync(ct);
        }
    }
}

