using Petanque.Services.Interfaces;
using Petanque.Storage;
using Microsoft.EntityFrameworkCore;

namespace Petanque.Services.Repositories;

public class KlassementRepository : IKlassementRepository
{
    private readonly Id312896PetanqueContext _context;

    public KlassementRepository(Id312896PetanqueContext context)
    {
        _context = context;
    }

    public async Task<List<Seizoensklassement>> GetSeizoensklassementBySeasonAsync(int seizoensId, CancellationToken ct = default)
    {
        return await _context.Seizoensklassements
            .Where(k => k.SeizoensId == seizoensId)
            .OrderByDescending(k => k.Hoofdpunten)
            .ThenByDescending(k => k.PlusMinPunten)
            .ToListAsync(ct);
    }
}