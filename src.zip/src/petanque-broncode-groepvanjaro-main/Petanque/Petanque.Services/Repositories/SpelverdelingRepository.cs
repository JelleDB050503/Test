using Petanque.Services.Interfaces;
using Petanque.Storage;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;

namespace Petanque.Services.Repositories
{
    public class SpelverdelingRepository : ISpelverdelingRepository
    {
        private readonly Id312896PetanqueContext _context;

        public SpelverdelingRepository(Id312896PetanqueContext context)
        {
            _context = context;
        }

        public async Task<Speeldag?> GetSpeeldagByIdAsync(int id, CancellationToken ct = default)
        {
            return await _context.Speeldags.FirstOrDefaultAsync(s => s.SpeeldagId == id, ct);
        }
    }
}

