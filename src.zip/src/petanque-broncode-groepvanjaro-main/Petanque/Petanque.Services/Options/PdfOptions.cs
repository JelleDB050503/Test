namespace Petanque.Services.Options;

public class PdfOptions
{
    // Basis page setup
    public float PageWidth { get; set; } = 595f; // A4 in points
    public float PageHeight { get; set; } = 842f;
    public float Margin { get; set; } = 24f;

    // Tekstopmaak
    public string DefaultFont { get; set; } = "Arial";
    public float DefaultFontSize { get; set; } = 10f;

    // Culture en formattering
    public string Culture { get; set; } = "nl-BE";

    // Layout details
    public float TableRowHeight { get; set; } = 16f;
    public float TableHeaderHeight { get; set; } = 18f;
    public float[] ColumnWidths { get; set; } = { 40f, 150f, 150f, 60f, 60f };
}