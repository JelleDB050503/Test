using Petanque.Services.Interfaces;
using Petanque.Services.Models;
using Petanque.Services.Options;
using QuestPDF.Fluent;
using QuestPDF.Helpers;

namespace Petanque.Services.Factories;

public class DagKlassementDocumentFactory : IDocumentFactory<DagKlassementPdfModel>
{
    private readonly PdfOptions _options;
    private readonly IDateTimeProvider _dateTimeProvider;

    public DagKlassementDocumentFactory(PdfOptions options, IDateTimeProvider dateTimeProvider)
    {
        _options = options;
        _dateTimeProvider = dateTimeProvider;
    }

    public Document CreateDocument(DagKlassementPdfModel model)
    {
        return Document.Create(container =>
        {
            container.Page(page =>
            {
                // keep the original layout behaviour
                page.Size(PageSizes.A4);
                page.Margin(20);
                page.DefaultTextStyle(x => x.FontSize(11));

                page.Content().Column(col =>
                {
                    string datumFormatted = _dateTimeProvider.Format(model.Datum, "d MMMM yyyy");

                    col.Item().Element(e => e
                        .PaddingBottom(2)
                        .Text($"VL@S - Dagklassement - {datumFormatted}")
                        .FontSize(14)
                        .Bold()
                        .AlignCenter());

                    col.Item().Element(e => e.PaddingTop(10));

                    col.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.ConstantColumn(25);
                            columns.RelativeColumn(3);
                            columns.ConstantColumn(35);
                            columns.ConstantColumn(35);
                        });

                        int rang = 1;
                        int prevHoofdpunten = int.MinValue;
                        int prevScore = int.MinValue;

                        foreach (var row in model.Rows)
                        {
                            bool isEvenRow = rang % 2 == 0;
                            string background = isEvenRow ? Colors.Grey.Lighten4 : Colors.White;

                            bool sameScore = (row.Hoofdpunten == prevHoofdpunten) && (row.Score == prevScore);
                            string rankText = sameScore ? " " : (row.Rank?.ToString() ?? rang.ToString());

                            table.Cell().Element(e => e.Background(background).PaddingVertical(2)).Text(rankText);
                            table.Cell().Element(e => e.Background(background).PaddingVertical(2)).Text($"{row.Naam} {row.Voornaam}");
                            table.Cell().Element(e => e.Background(background).PaddingVertical(2)).AlignCenter().Text(row.Hoofdpunten.ToString());
                            table.Cell().Element(e => e.Background(background).PaddingVertical(2)).AlignCenter().Text(row.Score.ToString());

                            prevHoofdpunten = row.Hoofdpunten;
                            prevScore = row.Score;
                            rang++;
                        }
                    });
                });
            });
        });
    }
}

