using Petanque.Services.Interfaces;
using Petanque.Services.Models;
using Petanque.Services.Options;
using QuestPDF.Fluent;
using QuestPDF.Helpers;

namespace Petanque.Services.Factories;

public class SpelverdelingDocumentFactory : IDocumentFactory<SpelverdelingPdfModel>
{
    private readonly PdfOptions _options;
    private readonly IDateTimeProvider _dateTimeProvider;

    public SpelverdelingDocumentFactory(PdfOptions options, IDateTimeProvider dateTimeProvider)
    {
        _options = options;
        _dateTimeProvider = dateTimeProvider;
    }

    public Document CreateDocument(SpelverdelingPdfModel model)
    {
        return Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.DefaultTextStyle(x => x.FontSize(12));

                page.Content().Column(col =>
                {
                    var spellenPerTerrein = model.Spellen
                        .GroupBy(spel => spel.Terrein)
                        .OrderBy(g => g.Key);

                    string datumFormatted = _dateTimeProvider.Format(model.Datum, "dddd d MMMM yyyy");

                    foreach (var terreinGroup in spellenPerTerrein)
                    {
                        col.Item().PaddingBottom(15).Row(r =>
                        {
                            r.RelativeItem().Text($"TERREIN: {terreinGroup.Key}")
                                .FontSize(18)
                                .Bold()
                                .Underline();
                            r.RelativeItem().AlignRight().Text(datumFormatted);
                        });

                        int spelnummer = 1;

                        foreach (var spel in terreinGroup)
                        {
                            var teamA = spel.Spelverdelingen.Where(x => x.Team == "Team A").ToList();
                            var teamB = spel.Spelverdelingen.Where(x => x.Team == "Team B").ToList();

                            col.Item().PaddingBottom(20).Border(1).Padding(15).Column(spelCol =>
                            {
                                spelCol.Item().Row(row =>
                                {
                                    row.RelativeItem().AlignCenter()
                                        .Background(Colors.BlueGrey.Darken2)
                                        .Padding(8)
                                        .Text($"Spel {spelnummer++}")
                                        .FontSize(16)
                                        .Bold()
                                        .FontColor(Colors.White);
                                });

                                spelCol.Item().PaddingTop(10);

                                spelCol.Item().Row(row =>
                                {
                                    // Team A
                                    row.RelativeItem().Column(teamCol =>
                                    {
                                        teamCol.Item().Text("Team A").FontSize(14).Bold().Underline();
                                        teamCol.Item().PaddingBottom(5);

                                        foreach (var speler in teamA)
                                        {
                                            var naam = speler.Speler != null
                                                ? $"{speler.SpelerVolgnr}. {speler.Speler.Naam} {speler.Speler.Voornaam}"
                                                : $"Onbekende speler (volgnr {speler.SpelerVolgnr})";
                                            teamCol.Item().Text(naam);
                                        }

                                        teamCol.Item().Row(scoreRow =>
                                        {
                                            for (int i = 0; i < 13; i++)
                                            {
                                                scoreRow.ConstantItem(18)
                                                    .Height(18)
                                                    .Border(1)
                                                    .PaddingRight(2);
                                            }
                                        });
                                        teamCol.Item().PaddingTop(1).Text("  1   2    3    4   5    6   7    8    9  10  11 12 13");
                                        teamCol.Item().PaddingTop(5).Text("Punten Team A:");
                                    });

                                    // Verticale lijn tussen teams
                                    row.ConstantItem(2).Height(120).Background(Colors.Grey.Lighten2);

                                    // Team B
                                    row.RelativeItem().Column(teamCol =>
                                    {
                                        teamCol.Item().Text("Team B").FontSize(14).Bold().Underline();
                                        teamCol.Item().PaddingBottom(5);

                                        foreach (var speler in teamB)
                                        {
                                            var naam = speler.Speler != null
                                                ? $"{speler.SpelerVolgnr}. {speler.Speler.Naam} {speler.Speler.Voornaam}"
                                                : $"Onbekende speler (volgnr {speler.SpelerVolgnr})";
                                            teamCol.Item().Text(naam);
                                        }

                                        teamCol.Item().Row(scoreRow =>
                                        {
                                            for (int i = 0; i < 13; i++)
                                            {
                                                scoreRow.ConstantItem(18)
                                                    .Height(18)
                                                    .Border(1)
                                                    .PaddingRight(2);
                                            }
                                        });
                                        teamCol.Item().PaddingTop(1).Text("  1   2    3    4   5    6   7    8    9  10  11 12 13");
                                        teamCol.Item().PaddingTop(5).Text("Punten Team B:");
                                    });
                                });
                            });
                        }

                        if (spellenPerTerrein.Any() && terreinGroup.Key != spellenPerTerrein.Last().Key)
                        {
                            col.Item().PageBreak();
                        }
                    }
                });
            });
        });
    }
}

