using Petanque.Services.Interfaces;
using Petanque.Services.Models;
using Petanque.Services.Options;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace Petanque.Services.Factories
{
    public class SeizoensKlassementDocumentFactory : IDocumentFactory<SeizoensKlassementPdfModel>
    {
        private readonly PdfOptions _options;
        private readonly IDateTimeProvider _dateTimeProvider;

        public SeizoensKlassementDocumentFactory(PdfOptions options, IDateTimeProvider dateTimeProvider)
        {
            _options = options;
            _dateTimeProvider = dateTimeProvider;
        }

        public Document CreateDocument(SeizoensKlassementPdfModel model)
        {
            return Document.Create(container =>
            {
                container.Page(page =>
                {
                    // identical base layout
                    page.Size(PageSizes.A4); 
                    page.Margin(20);
                    page.DefaultTextStyle(x => x.FontSize(11));

                    page.Content().Column(col =>
                    {
                        // Titel
                        col.Item().Element(e => e
                            .PaddingBottom(2)
                            .Text($"VL@S Seizoensklassement {model.SeizoenNaam ?? ""}")
                            .FontSize(14)
                            .Bold()
                            .AlignCenter());

                        // Ruimte tussen titel en tabel
                        col.Item().Element(e => e.PaddingTop(10));

                        // Tabel
                        col.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.ConstantColumn(25);   // Rang
                                columns.RelativeColumn(3);    // Naam
                                columns.ConstantColumn(35);   // Hoofdpunten
                                columns.ConstantColumn(35);   // +/- punten
                            });

                            int rang = 1;
                            int prevHoofdpunten = 0;
                            int prevPlusMinPunten = 0;

                            foreach (var row in model.Rows)
                            {
                                bool isEvenRow = rang % 2 == 0;
                                string background = isEvenRow ? Colors.Grey.Lighten4 : Colors.White;

                                bool sameScore = (row.Hoofdpunten == prevHoofdpunten) && (row.PlusMinPunten == prevPlusMinPunten);
                                string rankText = sameScore ? " " : rang.ToString();

                                table.Cell().Element(e => e.Background(background).PaddingVertical(2)).Text(rankText);
                                table.Cell().Element(e => e.Background(background).PaddingVertical(2)).Text($"{row.Naam} {row.Voornaam}");
                                table.Cell().Element(e => e.Background(background).PaddingVertical(2)).AlignCenter().Text(row.Hoofdpunten.ToString());
                                table.Cell().Element(e => e.Background(background).PaddingVertical(2)).AlignCenter().Text(row.PlusMinPunten.ToString());

                                prevHoofdpunten = row.Hoofdpunten;
                                prevPlusMinPunten = row.PlusMinPunten;
                                rang++;
                            }
                        });
                    });
                });
            });
        }
    }
}
