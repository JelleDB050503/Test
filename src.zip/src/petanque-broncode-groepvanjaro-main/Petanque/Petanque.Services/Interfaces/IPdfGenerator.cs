namespace Petanque.Services.Interfaces;

public interface IPdfGenerator
{
    Stream Generate<TModel>(TModel model, IDocumentFactory<TModel> factory, CancellationToken ct = default);
}