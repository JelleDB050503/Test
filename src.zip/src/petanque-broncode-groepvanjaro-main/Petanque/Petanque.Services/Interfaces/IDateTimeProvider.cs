namespace Petanque.Services.Interfaces;

public interface IDateTimeProvider
{
    DateTime Now { get; }
    string Format(DateTime dt, string format);
}