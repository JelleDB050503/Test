using Petanque.Storage;
using System.Threading;
using System.Threading.Tasks;

namespace Petanque.Services.Interfaces
{
    public interface ISpelverdelingRepository
    {
        Task<Speeldag?> GetSpeeldagByIdAsync(int id, CancellationToken ct = default);
    }
}

