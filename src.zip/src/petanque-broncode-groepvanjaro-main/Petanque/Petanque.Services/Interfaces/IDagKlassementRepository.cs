using Petanque.Storage;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Petanque.Services.Interfaces
{
    public interface IDagKlassementRepository
    {
        Task<Speeldag?> GetSpeeldagByIdAsync(int id, CancellationToken ct = default);
        Task<List<Dagklassement>> GetDagklassementsBySpeeldagIdAsync(int speeldagId, CancellationToken ct = default);
        Task<List<Speler>> GetSpelersByIdsAsync(List<int> spelerIds, CancellationToken ct = default);
    }
}

