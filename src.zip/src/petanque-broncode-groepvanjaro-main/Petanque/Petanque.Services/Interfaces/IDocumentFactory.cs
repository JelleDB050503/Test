using QuestPDF.Fluent;

namespace Petanque.Services.Interfaces;

public interface IDocumentFactory<TModel>
{
    Document CreateDocument(TModel model);
}