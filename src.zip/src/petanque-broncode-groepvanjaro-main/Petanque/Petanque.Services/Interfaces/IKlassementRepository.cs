using Petanque.Storage;

namespace Petanque.Services.Interfaces;

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public interface IKlassementRepository
{
    Task<List<Seizoensklassement>> GetSeizoensklassementBySeasonAsync(int seizoensId, CancellationToken ct = default);
}