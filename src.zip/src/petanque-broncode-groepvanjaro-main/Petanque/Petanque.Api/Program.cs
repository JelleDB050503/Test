using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Petanque.Api.Controllers;
using Petanque.Services;
using Petanque.Services.Interfaces;
using Petanque.Services.Options;
using Petanque.Services.Repositories;
using Petanque.Services.Services;
using Petanque.Storage;
using QuestPDF.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

QuestPDF.Settings.License = LicenseType.Community; // Deze regel kan nu mogelijk niet werken als 'LicenseType' niet bestaat


builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend",
        policy => policy.WithOrigins("*")
                        .AllowAnyMethod()
                        .AllowAnyHeader());
});

builder.Services.AddControllers();

// Verbinding met de MySQL database
var connectionString = builder.Configuration.GetConnectionString("LocalMySQL");
builder.Services.AddDbContext<Id312896PetanqueContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Services toevoegen
builder.Services.AddScoped<IPlayerService, PlayerService>();
builder.Services.AddScoped<IDagKlassementService, DagKlassementService>();
builder.Services.AddScoped<ISpelverdelingService, SpelverdelingService>();
builder.Services.AddScoped<IAanwezigheidService, AanwezigheidService>();
builder.Services.AddScoped<IScoreService, ScoreService>();
builder.Services.AddScoped<ISpeeldagService, SpeeldagService>();
builder.Services.AddScoped<IDagKlassementPDFService, DagKlassementPDFService>();
builder.Services.AddScoped<ISpelverdelingPDFService, SpelverdelingPDFService>();
builder.Services.AddScoped<ISeizoensKlassementPDFService, SeizoensKlassementPDFService>();
builder.Services.AddScoped<ISeizoensService, SeizoensService>();

// PDF service & configuration
builder.Services.Configure<PdfOptions>(builder.Configuration.GetSection("PdfOptions"));
builder.Services.AddSingleton(resolver =>
    resolver.GetRequiredService<IOptions<PdfOptions>>().Value);
builder.Services.AddSingleton<IDateTimeProvider, SystemDateTimeProvider>();

/*var provider = new SystemDateTimeProvider(Options.Create(new PdfOptions { Culture = "nl-BE" }));
Console.WriteLine(provider.Format(DateTime.Now, "d MMMM yyyy"));*/

// repositories
builder.Services.AddScoped<IKlassementRepository, KlassementRepository>();
builder.Services.AddScoped<Petanque.Services.Interfaces.IDagKlassementRepository, Petanque.Services.Repositories.DagKlassementRepository>();
builder.Services.AddScoped<Petanque.Services.Interfaces.ISpelverdelingRepository, Petanque.Services.Repositories.SpelverdelingRepository>();

// PDF generator
builder.Services.AddSingleton<IPdfGenerator, QuestPdfGenerator>();

var app = builder.Build();

app.UseCors("AllowFrontend");

app.MapControllers();
app.UseHttpsRedirection();
app.UseRouting();

var dbcontext = new Id312896PetanqueContext();
dbcontext.TestConnection();
dbcontext.Migration1();

app.Run();
