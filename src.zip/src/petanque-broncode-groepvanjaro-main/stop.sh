#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

BACKUP_DIR="manage-db/backups"
mkdir -p "$BACKUP_DIR"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log() { echo "[$(timestamp)] $*"; }

log "Stopping all components..."

for proc in dotnet node; do
  if pgrep -x "$proc" >/dev/null; then
    log "Stopping $proc..."
    pkill -f "$proc" || true
    sleep 2
    log "Force stopping $proc (if still running)..."
    pkill -9 -f "$proc" || true
  fi
done

log "Backing up database..."
if mariadb -u root -proot -e "USE petanque;" >/dev/null 2>&1; then
  /usr/bin/mariadb-dump -u root -proot petanque > "$BACKUP_DIR/backup_stop_$(date +%Y%m%d_%H%M%S).sql"
  log "Backup created."
else
  log "Database 'petanque' not found — skipping backup."
fi

log "Klaar!"
